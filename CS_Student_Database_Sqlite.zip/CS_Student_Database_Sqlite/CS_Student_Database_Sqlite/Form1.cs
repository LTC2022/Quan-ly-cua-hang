﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace CS_Student_Database_Sqlite
{
    public partial class Form1 : Form
    {
        private SQLiteConnection sqlconn;
        private SQLiteCommand sqlCmd;
        private DataTable sqlDT = new DataTable();
        private DataSet DS = new DataSet();
        private SQLiteDataAdapter DB;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void SetConnection()
        {
            sqlconn = new SQLiteConnection("Data Source = C:\\Users\\dvong0\\source\\repos\\CS_Student_Database_Sqlite\\CS_Student_Database_Sqlite\\bin\\Debug\\Student.db");
        }
        private void ExecuteQuery(string StudentIDq)
        {
            SetConnection();
            sqlconn.Open();
            sqlCmd = sqlconn.CreateCommand();
            sqlCmd.CommandText = StudentIDq;
            sqlCmd.ExecuteNonQuery();
            sqlCmd.Dispose();
            sqlconn.Close();
        }
        private void LoadData()
        {
            SetConnection();
            sqlconn.Open();

            sqlCmd = sqlconn.CreateCommand();
            string CommandText = "select * from Student";
            DB = new SQLiteDataAdapter(CommandText, sqlconn);
            DS.Reset();
            DB.Fill(DS);
            sqlDT = DS.Tables[0];
            dataGridView1.DataSource = sqlDT;
            sqlconn.Close();
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit", "Student Database", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        void ClearAllText(Control con)
        {
            foreach (Control c in con.Controls)
            {
                if (c is TextBox)
                    ((TextBox)c).Clear();
                else
                    ClearAllText(c);
            }
        }
        private void BtnReset_Click(object sender, EventArgs e)
        {
            ClearAllText(this);
            cmbCourseCode.Text = "";
            cmbGender.Text = "";
            rtTranscript.Text = "";
        }

        private void NumbersOnly(object sender, KeyPressEventArgs e)
        {
            int asciiCode = Convert.ToInt32(e.KeyChar);
            if ((asciiCode != 8))
            {
                if ((asciiCode >= 48 && asciiCode <= 57))
                {
                    e.Handled = false;
                }
                else
                {
                    MessageBox.Show("Number Only Please!", "Error: Number Only", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    e.Handled = true;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtStudent_ID.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            cmbCourseCode.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtAddMaths.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txtMaths.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            txtBusiness.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            txtBiology.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            txtChemistry.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            txtComputing.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            txtEnglish.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            txtPhysics.Text = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
            txtTotalScore.Text = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
            txtAverage.Text = dataGridView1.SelectedRows[0].Cells[11].Value.ToString();
            txtRanking.Text = dataGridView1.SelectedRows[0].Cells[12].Value.ToString();
        }

        private void BtnStudentResult_Click(object sender, EventArgs e)
        {
            rtTranscript.AppendText("Student ID :\t\t\t\t" + txtStudent_ID.Text + "\n");
            rtTranscript.AppendText("Name :\t\t\t\t" + txtFirstname.Text + " " + txtSurname.Text + "\n");
            rtTranscript.AppendText("Course Code :\t\t\t\t" + cmbCourseCode.Text + "\n");
            rtTranscript.AppendText("Add Maths :\t\t\t\t" + txtAddMaths.Text + "\n");
            rtTranscript.AppendText("Maths :\t\t\t\t" + txtMaths.Text + "\n");
            rtTranscript.AppendText("Business :\t\t\t\t" + txtBusiness.Text + "\n");
            rtTranscript.AppendText("Biology :\t\t\t\t" + txtBiology.Text + "\n");
            rtTranscript.AppendText("Chemistry :\t\t\t\t" + txtChemistry.Text + "\n");
            rtTranscript.AppendText("Computing :\t\t\t\t" + txtComputing.Text + "\n");
            rtTranscript.AppendText("English :\t\t\t\t" + txtEnglish.Text + "\n");
            rtTranscript.AppendText("Physics :\t\t\t\t" + txtPhysics.Text + "\n");
            rtTranscript.AppendText("Total Score :\t\t\t\t" + txtTotalScore.Text + "\n");
            rtTranscript.AppendText("Average :\t\t\t\t" + txtAverage.Text + "\n");
            rtTranscript.AppendText("Ranking :\t\t\t\t" + txtRanking.Text + "\n");

        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            string StudentIDq = "insert into Student (StudentID, CourseCode, Firstname, Surname, Maths, English, Biology, Computing, Chemistry, Physics, AddMaths, Business, Total, " +
                "Average, Ranking) value ('" + txtStudent_ID.Text + "','" + cmbCourseCode.Text + "','" + txtFirstname.Text + "','" + txtSurname.Text + "','" + txtMaths + "','" + 
                txtEnglish.Text + "','" + txtBiology.Text + "','" + txtComputing.Text + "','" + txtChemistry.Text + "','" + txtPhysics.Text + "','" + txtAddMaths.Text + "','" + 
                txtBusiness.Text + "','" + txtTotalScore.Text + "'.'" + txtAverage.Text + "','" + txtRanking.Text + "')";
            ExecuteQuery(StudentIDq);
            LoadData();
        }
    }
}

    
